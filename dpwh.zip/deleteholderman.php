<?php
$id = $_GET['id'];
$act = $_GET['act'];


?>

<form method="POST" action="query.php" id="myform">
  <input type="text" name="id" value="<?php echo $id?>">
  <input type="text" name="act" value="<?php echo $act?>">
  <input type="submit">
</form>

<script type="text/javascript">
  document.getElementById("myform").submit();
</script>
