<?php
include("connect.php");

$act = $_POST['act'];

switch($act){
	case "addadmin":
		
		$username = $_POST['username'];
		$pass = $_POST['pass'];
		$fname = $_POST['fname'];
		$mname = $_POST['mname'];
		$lname = $_POST['lname'];
		$sql = "INSERT INTO tbl_admin(username, pass, fname, mname, lname) VALUES('$username', '$pass', '$fname', '$mname', '$lname')";
		$conn->query($sql);
		echo "<script>alert('Admin has been added!')</script><script>window.location.href = 'addadmin.php';</script>";
	break;
	case "editadmin":
		$id = $_POST['id'];
		$username = $_POST['username'];
		$pass = $_POST['pass'];
		$fname = $_POST['fname'];
		$mname = $_POST['mname'];
		$lname = $_POST['lname'];
		$sql = "UPDATE tbl_admin SET username = '$username', pass = '$pass', fname = '$fname', mname = '$mname', lname = '$lname' WHERE id = '$id'";
		$conn->query($sql);
		echo "<script>alert('Admin has been Edited!')</script><script>window.location.href = 'editadmin.php';</script>";
	break;
	case "deleteadmin":
		$id = $_POST['id'];
		$sql = "DELETE FROM tbl_admin WHERE id = '$id'";
		$conn->query($sql);
		echo "<script>alert('Admin has been Removed!')</script><script>window.location.href = 'deleteadmin.php';</script>";
	break;
	case "addman":
		$name = $_POST['name'];
		$pos = $_POST['pos'];
		$con = $_POST['con'];
		$sql = "INSERT INTO tbl_manpower(name, position, contact) VALUES('$name', '$pos', '$con')";
		$conn->query($sql);
		echo "<script>alert('Profile has been added!')</script><script>window.location.href = 'addman.php';</script>";
	break;
	case "editman":
		$id = $_POST['id'];
		$name = $_POST['name'];
		$pos = $_POST['pos'];
		$con = $_POST['con'];
		$sql = "UPDATE tbl_manpower SET name = '$name', position = '$pos', contact = '$con' WHERE id = '$id'";
		$conn->query($sql);
		echo "<script>alert('Profile has been Edited!')</script><script>window.location.href = 'editman.php';</script>";
	break;
	case "deleteman":
		$id = $_POST['id'];
		$sql = "DELETE FROM tbl_manpower WHERE id = '$id'";
		$conn->query($sql);
		echo "<script>alert('Profile has been Removed!')</script><script>window.location.href = 'deleteman.php';</script>";
	break;
	case "addp":
		$pname = $_POST['pname'];
		$sdate = $_POST['sdate'];
		$edate = $_POST['edate'];
		$lat = $_POST['lat'];
		$lon = $_POST['lon'];
		$loc = $_POST['loc'];
		$man = $_POST['man'];
		$sql = "INSERT INTO tbl_projects(pname, sdate, edate, lat, lon, loc, manpower) VALUES('$pname', '$sdate', '$edate', '$lat', '$lon', '$loc', '$man')";
		$conn->query($sql);
		echo "<script>alert('Project has been added!')</script><script>window.location.href = 'main.php';</script>";
	break;
	case "editp":
		$id = $_POST['id'];
		$pname = $_POST['pname'];
		$sdate = $_POST['sdate'];
		$edate = $_POST['edate'];
		$lat = $_POST['lat'];
		$lon = $_POST['lon'];
		$loc = $_POST['loc'];
		$man = $_POST['man'];
		$sql = "UPDATE tbl_projects SET pname='$pname', sdate='$sdate', edate='$edate', lat='$lat', lon='$lon', loc='$loc', manpower='$man' WHERE id='$id'";
		$conn->query($sql);
		echo "<script>alert('Project has been Edited!')</script><script>window.location.href = 'main.php';</script>";
	break;
	case "deletep":
		$id = $_POST['id'];
		$sql = "DELETE FROM tbl_projects WHERE id = '$id'";
		$conn->query($sql);
		echo "<script>alert('Project has been Removed!')</script><script>window.location.href = 'deletep.php';</script>";
	break;
}
?>